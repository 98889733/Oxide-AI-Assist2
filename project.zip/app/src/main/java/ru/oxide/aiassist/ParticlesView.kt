package ru.oxide.aiassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Фон главного экрана: мерцающие точки летают по экрану.
 * Когда две точки рядом, между ними появляется линия; чем дальше, тем она бледнее и пропадает.
 */
class ParticlesView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private class P(
        var x: Float,
        var y: Float,
        var vx: Float,
        var vy: Float,
        val r: Float,
        val phase: Float,
        val speed: Float
    )

    private val density = resources.displayMetrics.density
    private val linkDist = 130f * density
    private val ps = ArrayList<P>()
    private val rnd = java.util.Random()
    private var last = 0L

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 1.3f * density
        color = Color.parseColor("#FF3B30")
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        ps.clear()
        if (w <= 0 || h <= 0) return
        val count = (w.toFloat() * h / 60000f).toInt().coerceIn(20, 70)
        for (i in 0 until count) {
            val angle = rnd.nextFloat() * 6.2831855f
            val sp = (8f + rnd.nextFloat() * 18f) * density
            ps.add(
                P(
                    rnd.nextFloat() * w, rnd.nextFloat() * h,
                    kotlin.math.cos(angle) * sp, sin(angle) * sp,
                    (1.5f + rnd.nextFloat() * 2.2f) * density,
                    rnd.nextFloat() * 6.28f,
                    1.2f + rnd.nextFloat() * 2.5f
                )
            )
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        last = 0L
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        var dt = if (last == 0L) 0.016f else (now - last) / 1000f
        if (dt > 0.05f) dt = 0.05f
        last = now
        val t = now / 1000f
        val accent = Theme.accent(context)
        val w = width.toFloat()
        val h = height.toFloat()

        for (p in ps) {
            p.x += p.vx * dt
            p.y += p.vy * dt
            if (p.x < 0f) {
                p.x = 0f
                p.vx = abs(p.vx)
            } else if (p.x > w) {
                p.x = w
                p.vx = -abs(p.vx)
            }
            if (p.y < 0f) {
                p.y = 0f
                p.vy = abs(p.vy)
            } else if (p.y > h) {
                p.y = h
                p.vy = -abs(p.vy)
            }
        }

        val maxD2 = linkDist * linkDist
        for (i in ps.indices) {
            val a = ps[i]
            for (j in i + 1 until ps.size) {
                val b = ps[j]
                val dx = a.x - b.x
                val dy = a.y - b.y
                val d2 = dx * dx + dy * dy
                if (d2 < maxD2) {
                    val k = 1f - sqrt(d2) / linkDist
                    linePaint.color = Theme.withAlpha(accent, (k * 150f).toInt())
                    canvas.drawLine(a.x, a.y, b.x, b.y, linePaint)
                }
            }
        }

        for (p in ps) {
            val tw = 0.5f + 0.5f * sin(t * p.speed + p.phase)
            val m = tw * 0.45f
            dotPaint.color = Color.argb(
                (110 + 145 * tw).toInt(),
                (Color.red(accent) + (255 - Color.red(accent)) * m).toInt(),
                (Color.green(accent) + (255 - Color.green(accent)) * m).toInt(),
                (Color.blue(accent) + (255 - Color.blue(accent)) * m).toInt()
            )
            canvas.drawCircle(p.x, p.y, p.r, dotPaint)
        }

        postInvalidateOnAnimation()
    }
}
