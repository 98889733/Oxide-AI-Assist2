package ru.oxide.aiassist

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

/**
 * Цветовая тема. Views помечены тегами:
 * t_accent: цветной текст, b_fill: залитая кнопка, b_line: кнопка с обводкой,
 * card: карточка, frame: рамка меню, dot_on / dot_off: индикатор.
 */
object Theme {

    val names = listOf(
        "Красный", "Зелёный", "Синий", "Жёлтый", "Розовый",
        "Тёмно-красный", "Тёмно-зелёный", "Оранжевый", "Радужный"
    )

    private val base = intArrayOf(
        Color.parseColor("#E53935"),
        Color.parseColor("#66BB6A"),
        Color.parseColor("#1E88E5"),
        Color.parseColor("#FDD835"),
        Color.parseColor("#EC407A"),
        Color.parseColor("#B71C1C"),
        Color.parseColor("#2E7D32"),
        Color.parseColor("#FB8C00")
    )

    fun index(ctx: Context): Int =
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getInt("theme", 0).coerceIn(0, 8)

    fun rainbow(): Int =
        Color.HSVToColor(floatArrayOf(((SystemClock.uptimeMillis() / 25) % 360).toFloat(), 0.85f, 1f))

    fun accent(ctx: Context): Int {
        val i = index(ctx)
        return if (i == 8) rainbow() else base[i]
    }

    fun onColor(c: Int): Int {
        val lum = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
        return if (lum > 0.6f) Color.BLACK else Color.WHITE
    }

    fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun round(fill: Int, stroke: Int, strokeDp: Float, radiusDp: Float, d: Float): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.RECTANGLE
        g.setColor(fill)
        g.cornerRadius = radiusDp * d
        if (strokeDp > 0f) g.setStroke((strokeDp * d).toInt().coerceAtLeast(1), stroke)
        return g
    }

    /** Чуть приглушённый цвет для заливки кнопок. */
    fun soft(c: Int): Int = Color.rgb(
        (Color.red(c) * 0.85f).toInt(),
        (Color.green(c) * 0.85f).toInt(),
        (Color.blue(c) * 0.85f).toInt()
    )

    fun fill(a: Int, d: Float): Drawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(128, 255, 255, 255)), round(soft(a), 0, 0f, 20f, d), null)

    fun line(a: Int, d: Float): Drawable =
        RippleDrawable(
            ColorStateList.valueOf(withAlpha(a, 128)),
            round(Color.parseColor("#FF1A1A1A"), withAlpha(a, 140), 1.5f, 20f, d), null
        )

    fun card(a: Int, d: Float): Drawable =
        round(Color.parseColor("#FF121212"), withAlpha(a, 70), 1f, 20f, d)

    fun frame(a: Int, d: Float): Drawable =
        round(Color.parseColor("#FF0A0A0A"), withAlpha(a, 150), 1.5f, 12f, d)

    fun dot(c: Int): Drawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(c)
        return g
    }

    /** Кружок выбора цвета в настройках. */
    fun chip(i: Int, selected: Boolean, d: Float): Drawable {
        val g = if (i == 8) {
            GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(
                    Color.RED, Color.YELLOW, Color.GREEN, Color.CYAN, Color.BLUE, Color.MAGENTA
                )
            )
        } else {
            val x = GradientDrawable()
            x.setColor(base[i])
            x
        }
        g.shape = GradientDrawable.RECTANGLE
        g.cornerRadius = 16f * d
        if (selected) {
            g.setStroke((4f * d).toInt(), Color.WHITE)
        } else {
            g.setStroke((1f * d).toInt().coerceAtLeast(1), Color.argb(90, 255, 255, 255))
        }
        return g
    }

    fun chipTextColor(i: Int): Int = if (i == 8) Color.WHITE else onColor(base[i])

    fun apply(root: View) {
        val ctx = root.context
        val a = accent(ctx)
        val d = ctx.resources.displayMetrics.density

        fun visit(v: View) {
            when (v.tag as? String) {
                "t_accent" -> (v as TextView).setTextColor(a)
                "b_fill" -> {
                    v.background = fill(a, d)
                    (v as TextView).setTextColor(onColor(soft(a)))
                }
                "b_line" -> {
                    v.background = line(a, d)
                    (v as TextView).setTextColor(Color.WHITE)
                }
                "card" -> v.background = card(a, d)
                "frame" -> v.background = frame(a, d)
                "dot_on" -> v.background = dot(a)
                "dot_off" -> v.background = dot(Color.parseColor("#555555"))
            }
            if (v is ViewGroup) {
                for (i in 0 until v.childCount) visit(v.getChildAt(i))
            }
        }
        visit(root)
    }
}

/** Применяет тему и следит за её изменением (нужно для радужной). */
class ThemeTicker(private val root: View) {
    private val handler = Handler(Looper.getMainLooper())
    private var last = 0
    private val tick = object : Runnable {
        override fun run() {
            val a = Theme.accent(root.context)
            if (a != last) {
                last = a
                Theme.apply(root)
            }
            handler.postDelayed(this, 150)
        }
    }

    fun start() {
        last = 0
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    fun stop() {
        handler.removeCallbacks(tick)
    }
}
