package ru.oxide.aiassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/**
 * Прозрачный слой поверх игры: только рисует (круг, рамки, стрелка).
 * Касания он не принимает: они проходят в игру.
 */
class AimView(context: Context) : View(context) {

    class Item(val box: RectF, val id: Int, val primary: Boolean, val inside: Boolean)

    private var items: List<Item> = emptyList()
    private var circleOn = false
    private var radius = 300f
    private var arrowAngle: Float? = null

    private val red = Color.parseColor("#E53935")
    private val green = Color.parseColor("#43A047")

    private val linePaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        isAntiAlias = true
    }
    private val textPaint = Paint().apply {
        textSize = 34f
        isFakeBoldText = true
        isAntiAlias = true
    }
    private val arrowPaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 16f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#E53935")
        isAntiAlias = true
    }

    fun setData(newItems: List<Item>, circle: Boolean, r: Float, angle: Float?) {
        items = newItems
        circleOn = circle
        radius = r
        arrowAngle = angle
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val anyInside = items.any { it.inside }

        if (circleOn) {
            linePaint.color = if (anyInside) green else red
            linePaint.strokeWidth = 5f
            canvas.drawCircle(cx, cy, radius, linePaint)
            canvas.drawCircle(cx, cy, 5f, linePaint)
        }

        for (item in items) {
            val color = if (item.inside) green else red
            linePaint.color = color
            linePaint.strokeWidth = if (item.primary) 8f else 4f
            canvas.drawRect(item.box, linePaint)
            textPaint.color = color
            canvas.drawText("№" + item.id, item.box.left, item.box.top - 8f, textPaint)
        }

        val a = arrowAngle
        if (a != null) {
            val d0 = if (circleOn) radius + 20f else 90f
            val len = 170f
            val x0 = cx + cos(a) * d0
            val y0 = cy + sin(a) * d0
            val x1 = cx + cos(a) * (d0 + len)
            val y1 = cy + sin(a) * (d0 + len)
            canvas.drawLine(x0, y0, x1, y1, arrowPaint)
            val back = a + 2.6f
            val back2 = a - 2.6f
            canvas.drawLine(x1, y1, x1 + cos(back) * 60f, y1 + sin(back) * 60f, arrowPaint)
            canvas.drawLine(x1, y1, x1 + cos(back2) * 60f, y1 + sin(back2) * 60f, arrowPaint)
        }
    }
}
