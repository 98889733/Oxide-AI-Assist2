package ru.oxide.aiassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Прозрачный слой поверх игры: только рисует (круг, рамки, стрелка).
 * Касания он не принимает: они проходят в игру.
 */
class AimView(context: Context) : View(context) {

    class Item(val box: RectF, val id: Int, val primary: Boolean, val inside: Boolean)

    private var items: List<Item> = emptyList()
    private var circleOn = false
    private var radius = 300f
    private var arrowAngle: Float? = null

    private var mapOn = false
    private var mpx: Float? = null
    private var mpy: Float? = null
    private var mwx: Float? = null
    private var mwy: Float? = null

    private val whitePaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 26f
        strokeCap = Paint.Cap.ROUND
        color = Color.WHITE
        isAntiAlias = true
    }

    private val red = Color.parseColor("#E53935")
    private val green = Color.parseColor("#43A047")

    private val linePaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        isAntiAlias = true
    }
    private val textPaint = Paint().apply {
        textSize = 34f
        isFakeBoldText = true
        isAntiAlias = true
    }
    private val arrowPaint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 16f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#E53935")
        isAntiAlias = true
    }

    fun setData(newItems: List<Item>, circle: Boolean, r: Float, angle: Float?) {
        mapOn = false
        items = newItems
        circleOn = circle
        radius = r
        arrowAngle = angle
        invalidate()
    }

    /** Режим карты: координаты в пикселях экрана (null, если не видно). */
    fun setMap(px: Float?, py: Float?, wx: Float?, wy: Float?) {
        mapOn = true
        items = emptyList()
        circleOn = false
        arrowAngle = null
        mpx = px
        mpy = py
        mwx = wx
        mwy = wy
        invalidate()
    }

    private fun drawArrow(canvas: Canvas, x0: Float, y0: Float, a: Float, len: Float) {
        val x1 = x0 + cos(a) * len
        val y1 = y0 + sin(a) * len
        for (paint in listOf(whitePaint, arrowPaint)) {
            canvas.drawLine(x0, y0, x1, y1, paint)
            canvas.drawLine(x1, y1, x1 + cos(a + 2.6f) * 60f, y1 + sin(a + 2.6f) * 60f, paint)
            canvas.drawLine(x1, y1, x1 + cos(a - 2.6f) * 60f, y1 + sin(a - 2.6f) * 60f, paint)
        }
    }

    private fun drawMap(canvas: Canvas) {
        val wx = mwx
        val wy = mwy
        val px = mpx
        val py = mpy
        if (wx != null && wy != null && wx >= 0f && wy >= 0f && wx <= width && wy <= height) {
            whitePaint.strokeWidth = 14f
            canvas.drawCircle(wx, wy, 40f, whitePaint)
            linePaint.color = red
            linePaint.strokeWidth = 8f
            canvas.drawCircle(wx, wy, 40f, linePaint)
            canvas.drawCircle(wx, wy, 8f, linePaint)
            whitePaint.strokeWidth = 26f
        }
        if (px != null && py != null && wx != null && wy != null) {
            val dx = wx - px
            val dy = wy - py
            if (hypot(dx, dy) > 70f) {
                val a = atan2(dy, dx)
                drawArrow(canvas, px + cos(a) * 45f, py + sin(a) * 45f, a, 220f)
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (mapOn) {
            drawMap(canvas)
            return
        }
        val cx = width / 2f
        val cy = height / 2f
        val anyInside = items.any { it.inside }

        if (circleOn) {
            linePaint.color = if (anyInside) green else red
            linePaint.strokeWidth = 5f
            canvas.drawCircle(cx, cy, radius, linePaint)
            canvas.drawCircle(cx, cy, 5f, linePaint)
        }

        for (item in items) {
            val color = if (item.inside) green else red
            linePaint.color = color
            linePaint.strokeWidth = if (item.primary) 8f else 4f
            canvas.drawRect(item.box, linePaint)
            textPaint.color = color
            canvas.drawText("№" + item.id, item.box.left, item.box.top - 8f, textPaint)
        }

        val a = arrowAngle
        if (a != null) {
            val d0 = if (circleOn) radius + 20f else 90f
            val len = 170f
            val x0 = cx + cos(a) * d0
            val y0 = cy + sin(a) * d0
            val x1 = cx + cos(a) * (d0 + len)
            val y1 = cy + sin(a) * (d0 + len)
            canvas.drawLine(x0, y0, x1, y1, arrowPaint)
            val back = a + 2.6f
            val back2 = a - 2.6f
            canvas.drawLine(x1, y1, x1 + cos(back) * 60f, y1 + sin(back) * 60f, arrowPaint)
            canvas.drawLine(x1, y1, x1 + cos(back2) * 60f, y1 + sin(back2) * 60f, arrowPaint)
        }
    }
}
