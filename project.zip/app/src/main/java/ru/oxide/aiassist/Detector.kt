package ru.oxide.aiassist

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.objectdetector.ObjectDetector

/**
 * Настоящая нейросеть (EfficientDet-Lite0, TensorFlow Lite) на телефоне.
 * Ищет на кадре объекты класса "person" (человек / гуманоид).
 */
class Detector(context: Context, sensitivity: Int) {

    class Target(val box: RectF, val score: Float)

    private val detector: ObjectDetector

    init {
        val threshold = when (sensitivity) {
            1 -> 0.6f
            3 -> 0.25f
            else -> 0.4f
        }
        val options = ObjectDetector.ObjectDetectorOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("detector.tflite").build())
            .setRunningMode(RunningMode.IMAGE)
            .setScoreThreshold(threshold)
            .setMaxResults(6)
            .setCategoryAllowlist(listOf("person"))
            .build()
        detector = ObjectDetector.createFromOptions(context, options)
    }

    fun detect(bitmap: Bitmap): List<Target> {
        val result = detector.detect(BitmapImageBuilder(bitmap).build())
        return result.detections().map { d ->
            Target(d.boundingBox(), d.categories()[0].score())
        }
    }

    fun close() {
        detector.close()
    }
}
