package ru.oxide.aiassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "oxide_overlay"
        private const val MAX_SIDE = 640f
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var infoText: TextView? = null
    private var previewView: ImageView? = null
    private var headerView: TextView? = null

    private var aimView: AimView? = null
    private var aimParams: WindowManager.LayoutParams? = null

    private var detector: Detector? = null
    private var detectorError: String? = null
    private val tracker = Tracker()
    private val boxPaint = Paint().apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val textPaint = Paint().apply {
        color = Color.YELLOW
        textSize = 24f
        isFakeBoldText = true
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var displayManager: DisplayManager? = null
    private var stopping = false

    private var vibrator: Vibrator? = null
    private var wasInside = false
    private var lastHaptic = 0L

    private var capW = 0
    private var capH = 0
    private var realW = 0
    private var realH = 0
    private var dpi = 0
    private var frames = 0L
    private var lastFrameTime = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlayView != null) return START_NOT_STICKY

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notification)
        }

        if (data == null || code != android.app.Activity.RESULT_OK) {
            stopSelf()
            return START_NOT_STICKY
        }

        vibrator = getSystemService(Vibrator::class.java)
        computeSize()
        showOverlay()
        running = true
        try {
            startCapture(code, data)
        } catch (e: Exception) {
            infoText?.text = "Ошибка захвата экрана:\n${e.message}"
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "OXIDE AI ASSIST", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("OXIDE AI ASSIST включён")
            .setContentText("Идёт захват экрана. Нажмите, чтобы открыть")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open)
            .build()
    }

    // ---------- плавающие окна ----------

    private fun attachDrag(
        handle: View,
        params: WindowManager.LayoutParams,
        root: View,
        onClick: (() -> Unit)?
    ) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (moved || abs(dx) > 12f || abs(dy) > 12f) {
                        moved = true
                        params.x = startX + dx.toInt()
                        params.y = startY + dy.toInt()
                        windowManager?.updateViewLayout(root, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onClick?.invoke()
                    true
                }
                else -> false
            }
        }
    }

    private fun showOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        // 1) прозрачный слой на весь экран (круг, рамки, стрелка); касания проходят в игру
        val av = AimView(this)
        val ap = WindowManager.LayoutParams(
            realW,
            realH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        wm.addView(av, ap)
        aimView = av
        aimParams = ap

        // 2) маленькое меню
        val view = LayoutInflater.from(this).inflate(R.layout.overlay, null)
        infoText = view.findViewById(R.id.overlayInfo)
        previewView = view.findViewById(R.id.preview)
        headerView = view.findViewById(R.id.dragHandle)
        infoText?.text = "Запуск захвата экрана…"

        val body = view.findViewById<View>(R.id.overlayBody)
        val toggle = view.findViewById<Button>(R.id.overlayToggle)
        val stopBtn = view.findViewById<Button>(R.id.overlayStop)
        val handle = view.findViewById<View>(R.id.dragHandle)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 160
        }

        var expanded = true
        fun setExpanded(value: Boolean) {
            expanded = value
            val vis = if (value) View.VISIBLE else View.GONE
            handle.visibility = vis
            stopBtn.visibility = vis
            body.visibility = vis
            toggle.text = if (value) "–" else "+"
        }

        // кнопку «–/+» можно и нажимать, и таскать
        attachDrag(toggle, params, view) { setExpanded(!expanded) }
        attachDrag(handle, params, view, null)
        stopBtn.setOnClickListener { stopSelf() }

        wm.addView(view, params)
        overlayView = view
    }

    // ---------- захват экрана ----------

    private fun computeSize() {
        val dm = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(dm)
        realW = dm.widthPixels
        realH = dm.heightPixels
        val scale = MAX_SIDE / maxOf(realW, realH)
        capW = maxOf(2, (realW * scale).toInt())
        capH = maxOf(2, (realH * scale).toInt())
        dpi = dm.densityDpi
    }

    private fun newReader(): ImageReader {
        val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd -> onFrame(rd) }, handler)
        return r
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            onScreenChanged()
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val t = HandlerThread("oxide-capture")
        t.start()
        thread = t
        val h = Handler(t.looper)
        handler = h

        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopping) mainHandler.post { stopSelf() }
            }
        }, h)

        val r = newReader()
        reader = r
        virtualDisplay = p.createVirtualDisplay(
            "oxide-capture", capW, capH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, h
        )

        val dmgr = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager = dmgr
        dmgr.registerDisplayListener(displayListener, h)
    }

    // экран повернулся (например, запустили игру в горизонтальном режиме)
    private fun onScreenChanged() {
        val oldW = capW
        val oldH = capH
        computeSize()

        val w = realW
        val hh = realH
        mainHandler.post {
            val ap = aimParams
            val av = aimView
            if (ap != null && av != null) {
                ap.width = w
                ap.height = hh
                try {
                    windowManager?.updateViewLayout(av, ap)
                } catch (e: Exception) {
                }
            }
        }

        if (oldW == capW && oldH == capH) return

        tracker.reset()
        val old = reader
        val r = newReader()
        reader = r
        virtualDisplay?.resize(capW, capH, dpi)
        virtualDisplay?.surface = r.surface
        old?.close()
    }

    // Подсказка вибрацией (только сообщает, куда повернуть; ничем не управляет):
    // цель вошла в круг: один длинный сигнал; цель слева: один короткий; справа: два коротких
    private fun haptic(enabled: Boolean, inside: Boolean, angle: Float?) {
        if (!enabled) {
            wasInside = false
            return
        }
        val v = vibrator ?: return
        val now = SystemClock.elapsedRealtime()
        if (inside && !wasInside) {
            v.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
            lastHaptic = now
        } else if (!inside && angle != null && now - lastHaptic > 1200L) {
            val right = cos(angle) >= 0f
            val pattern = if (right) longArrayOf(0, 70, 90, 70) else longArrayOf(0, 70)
            v.vibrate(VibrationEffect.createWaveform(pattern, -1))
            lastHaptic = now
        }
        wasInside = inside
    }

    private fun describe(fx: Float, fy: Float): String {
        val hor = when {
            fx < 0.4f -> "слева"
            fx > 0.6f -> "справа"
            else -> "по центру"
        }
        val ver = when {
            fy < 0.4f -> "выше"
            fy > 0.6f -> "ниже"
            else -> "в середине"
        }
        return "$hor, $ver"
    }

    private fun onFrame(rd: ImageReader) {
        val img = rd.acquireLatestImage() ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
            val fps = prefs.getInt("fps", 5)
            if (now - lastFrameTime < 1000L / fps) return
            lastFrameTime = now

            val plane = img.planes[0]
            val w = img.width
            val h = img.height
            val full = Bitmap.createBitmap(plane.rowStride / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val bmp = if (full.width == w) full else Bitmap.createBitmap(full, 0, 0, w, h)

            if (detector == null && detectorError == null) {
                try {
                    detector = Detector(this, prefs.getInt("sens", 2))
                } catch (e: Throwable) {
                    detectorError = e.message ?: e.javaClass.simpleName
                }
            }

            var targets = emptyList<Detector.Target>()
            var ms = 0L
            val det = detector
            if (det != null) {
                val t0 = SystemClock.elapsedRealtime()
                targets = try {
                    det.detect(bmp)
                } catch (e: Throwable) {
                    detectorError = e.message ?: e.javaClass.simpleName
                    emptyList<Detector.Target>()
                }
                ms = SystemClock.elapsedRealtime() - t0
            }

            // отслеживание между кадрами
            val confirmed = tracker.update(targets, 0.15f * maxOf(w, h))

            // превью в меню
            val shown = bmp.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(shown)
            for (t in confirmed) {
                val l = t.cx - t.w / 2f
                val tp = t.cy - t.h / 2f
                canvas.drawRect(l, tp, l + t.w, tp + t.h, boxPaint)
                canvas.drawText("№" + t.id, l + 4f, tp + 24f, textPaint)
            }

            // координаты на весь экран, круг и стрелка
            val rw = realW
            val rh = realH
            val sx = rw.toFloat() / w
            val sy = rh.toFloat() / h
            val circleMode = prefs.getInt("circle", 2)
            val circleOn = circleMode > 0
            val factor = when (circleMode) {
                1 -> 0.18f
                3 -> 0.38f
                else -> 0.28f
            }
            val radius = minOf(rw, rh) * factor
            val mcx = rw / 2f
            val mcy = rh / 2f

            var primary: Tracker.Track? = null
            var bestD = Float.MAX_VALUE
            for (t in confirmed) {
                val d = hypot(t.cx * sx - mcx, t.cy * sy - mcy)
                if (d < bestD) {
                    bestD = d
                    primary = t
                }
            }
            val prim = primary

            val items = confirmed.map { t ->
                val cxs = t.cx * sx
                val cys = t.cy * sy
                val d = hypot(cxs - mcx, cys - mcy)
                val box = RectF(
                    cxs - t.w * sx / 2f, cys - t.h * sy / 2f,
                    cxs + t.w * sx / 2f, cys + t.h * sy / 2f
                )
                AimView.Item(box, t.id, t === prim, circleOn && d <= radius)
            }
            val insideCount = items.count { it.inside }

            var angle: Float? = null
            if (prim != null) {
                val dx = prim.cx * sx - mcx
                val dy = prim.cy * sy - mcy
                val limit = if (circleOn) radius else 120f
                if (hypot(dx, dy) > limit) angle = atan2(dy, dx)
            }

            haptic(prefs.getInt("haptic", 1) == 1, insideCount > 0, angle)

            frames++
            val n = frames
            val err = detectorError
            val sb = StringBuilder()
            if (err != null) {
                sb.append("ИИ не запущен:\n").append(err)
            } else {
                sb.append("Кадров: $n, ИИ: $ms мс\nЦелей: ${items.size}")
                if (circleOn) sb.append(" (в круге: $insideCount)")
                if (prim != null) {
                    sb.append("\nБлижняя №${prim.id}: ${describe(prim.cx / w, prim.cy / h)}")
                }
            }
            val header = if (err != null) "☰ OXIDE" else "☰ OXIDE · целей: ${items.size}"
            val text = sb.toString()
            val finalAngle = angle

            mainHandler.post {
                previewView?.setImageBitmap(shown)
                infoText?.text = text
                headerView?.text = header
                aimView?.setData(items, circleOn, radius, finalAngle)
            }
        } finally {
            img.close()
        }
    }

    override fun onDestroy() {
        stopping = true
        try {
            displayManager?.unregisterDisplayListener(displayListener)
        } catch (e: Exception) {
        }
        virtualDisplay?.release()
        virtualDisplay = null
        reader?.close()
        reader = null
        projection?.stop()
        projection = null
        val d = detector
        detector = null
        handler?.post { d?.close() }
        thread?.quitSafely()
        thread = null

        overlayView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
            }
        }
        overlayView = null
        aimView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
            }
        }
        aimView = null
        running = false
        super.onDestroy()
    }
}
