package ru.oxide.aiassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

class OverlayService : Service() {

    companion object {
        @Volatile
        var running = false
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL_ID = "oxide_overlay"
        private const val MAX_SIDE = 640f
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var infoText: TextView? = null
    private var previewView: ImageView? = null
    private var headerView: TextView? = null

    private var detector: Detector? = null
    private var detectorError: String? = null
    private val boxPaint = Paint().apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val textPaint = Paint().apply {
        color = Color.YELLOW
        textSize = 24f
        isFakeBoldText = true
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var displayManager: DisplayManager? = null
    private var stopping = false

    private var capW = 0
    private var capH = 0
    private var dpi = 0
    private var frames = 0L
    private var lastFrameTime = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (overlayView != null) return START_NOT_STICKY

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notification)
        }

        if (data == null || code != android.app.Activity.RESULT_OK) {
            stopSelf()
            return START_NOT_STICKY
        }

        showOverlay()
        running = true
        try {
            startCapture(code, data)
        } catch (e: Exception) {
            infoText?.text = "Ошибка захвата экрана:\n${e.message}"
        }
        return START_NOT_STICKY
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "OXIDE AI ASSIST", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("OXIDE AI ASSIST включён")
            .setContentText("Идёт захват экрана. Нажмите, чтобы открыть")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentIntent(open)
            .build()
    }

    // ---------- плавающее окно ----------

    private fun showOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val view = LayoutInflater.from(this).inflate(R.layout.overlay, null)
        infoText = view.findViewById(R.id.overlayInfo)
        previewView = view.findViewById(R.id.preview)
        headerView = view.findViewById(R.id.dragHandle)
        infoText?.text = "Запуск захвата экрана…"

        val body = view.findViewById<View>(R.id.overlayBody)
        val toggle = view.findViewById<Button>(R.id.overlayToggle)
        toggle.setOnClickListener {
            if (body.visibility == View.VISIBLE) {
                body.visibility = View.GONE
                toggle.text = "+"
            } else {
                body.visibility = View.VISIBLE
                toggle.text = "–"
            }
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 240
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        view.findViewById<View>(R.id.dragHandle).setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(view, params)
                    true
                }
                else -> false
            }
        }

        view.findViewById<Button>(R.id.overlayStop).setOnClickListener { stopSelf() }

        wm.addView(view, params)
        overlayView = view
    }

    // ---------- захват экрана ----------

    private fun computeSize() {
        val dm = DisplayMetrics()
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(dm)
        val scale = MAX_SIDE / maxOf(dm.widthPixels, dm.heightPixels)
        capW = maxOf(2, (dm.widthPixels * scale).toInt())
        capH = maxOf(2, (dm.heightPixels * scale).toInt())
        dpi = dm.densityDpi
    }

    private fun newReader(): ImageReader {
        val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        r.setOnImageAvailableListener({ rd -> onFrame(rd) }, handler)
        return r
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) {}
        override fun onDisplayRemoved(displayId: Int) {}
        override fun onDisplayChanged(displayId: Int) {
            onScreenChanged()
        }
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

        val t = HandlerThread("oxide-capture")
        t.start()
        thread = t
        val h = Handler(t.looper)
        handler = h

        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                if (!stopping) mainHandler.post { stopSelf() }
            }
        }, h)

        computeSize()
        val r = newReader()
        reader = r
        virtualDisplay = p.createVirtualDisplay(
            "oxide-capture", capW, capH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, h
        )

        val dmgr = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager = dmgr
        dmgr.registerDisplayListener(displayListener, h)
    }

    // экран повернулся (например, запустили игру в горизонтальном режиме)
    private fun onScreenChanged() {
        val oldW = capW
        val oldH = capH
        computeSize()
        if (oldW == capW && oldH == capH) return

        val old = reader
        val r = newReader()
        reader = r
        virtualDisplay?.resize(capW, capH, dpi)
        virtualDisplay?.surface = r.surface
        old?.close()
    }

    private fun describe(box: RectF, w: Int, h: Int): String {
        val cx = box.centerX() / w
        val cy = box.centerY() / h
        val hor = when {
            cx < 0.4f -> "слева"
            cx > 0.6f -> "справа"
            else -> "по центру"
        }
        val ver = when {
            cy < 0.4f -> "выше"
            cy > 0.6f -> "ниже"
            else -> "в середине"
        }
        return "$hor, $ver"
    }

    private fun onFrame(rd: ImageReader) {
        val img = rd.acquireLatestImage() ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
            val fps = prefs.getInt("fps", 5)
            if (now - lastFrameTime < 1000L / fps) return
            lastFrameTime = now

            val plane = img.planes[0]
            val w = img.width
            val h = img.height
            val full = Bitmap.createBitmap(plane.rowStride / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            val bmp = if (full.width == w) full else Bitmap.createBitmap(full, 0, 0, w, h)

            if (detector == null && detectorError == null) {
                try {
                    detector = Detector(this, prefs.getInt("sens", 2))
                } catch (e: Throwable) {
                    detectorError = e.message ?: e.javaClass.simpleName
                }
            }

            var targets = emptyList<Detector.Target>()
            var ms = 0L
            val det = detector
            if (det != null) {
                val t0 = SystemClock.elapsedRealtime()
                targets = try {
                    det.detect(bmp)
                } catch (e: Throwable) {
                    detectorError = e.message ?: e.javaClass.simpleName
                    emptyList<Detector.Target>()
                }
                ms = SystemClock.elapsedRealtime() - t0
            }

            val shown = bmp.copy(Bitmap.Config.ARGB_8888, true)
            val canvas = Canvas(shown)
            for (t in targets) {
                canvas.drawRect(t.box, boxPaint)
                canvas.drawText("${(t.score * 100).toInt()}%", t.box.left + 4f, t.box.top + 24f, textPaint)
            }

            frames++
            val n = frames
            val err = detectorError
            val sb = StringBuilder()
            if (err != null) {
                sb.append("ИИ не запущен:\n").append(err)
            } else {
                sb.append("Кадров: $n, ИИ: $ms мс\nЦелей: ${targets.size}")
                targets.take(3).forEachIndexed { i, t ->
                    sb.append("\n${i + 1}) ${describe(t.box, w, h)}, ${(t.score * 100).toInt()}%")
                }
            }
            val header = if (err != null) "☰ OXIDE" else "☰ OXIDE · целей: ${targets.size}"
            val text = sb.toString()

            mainHandler.post {
                previewView?.setImageBitmap(shown)
                infoText?.text = text
                headerView?.text = header
            }
        } finally {
            img.close()
        }
    }

    override fun onDestroy() {
        stopping = true
        try {
            displayManager?.unregisterDisplayListener(displayListener)
        } catch (e: Exception) {
        }
        virtualDisplay?.release()
        virtualDisplay = null
        reader?.close()
        reader = null
        projection?.stop()
        projection = null
        val d = detector
        detector = null
        handler?.post { d?.close() }
        thread?.quitSafely()
        thread = null

        overlayView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
            }
        }
        overlayView = null
        running = false
        super.onDestroy()
    }
}
