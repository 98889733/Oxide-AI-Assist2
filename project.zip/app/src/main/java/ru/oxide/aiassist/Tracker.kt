package ru.oxide.aiassist

import kotlin.math.hypot

/**
 * Простое отслеживание целей между кадрами: каждой цели даётся номер,
 * пока она рядом с прошлым положением, номер сохраняется.
 */
class Tracker {

    class Track(
        val id: Int,
        var cx: Float,
        var cy: Float,
        var w: Float,
        var h: Float
    ) {
        var vx = 0f
        var vy = 0f
        var missed = 0
        var hits = 1
    }

    private val tracks = ArrayList<Track>()
    private var nextId = 1

    fun reset() {
        tracks.clear()
    }

    /** Возвращает подтверждённые цели (замеченные минимум на двух кадрах). */
    fun update(dets: List<Detector.Target>, maxDist: Float): List<Track> {
        val used = BooleanArray(dets.size)

        for (t in tracks) {
            val px = t.cx + t.vx
            val py = t.cy + t.vy
            var best = -1
            var bestD = maxDist
            for (i in dets.indices) {
                if (used[i]) continue
                val d = hypot(dets[i].box.centerX() - px, dets[i].box.centerY() - py)
                if (d < bestD) {
                    bestD = d
                    best = i
                }
            }
            if (best >= 0) {
                used[best] = true
                val b = dets[best].box
                val dx = b.centerX() - t.cx
                val dy = b.centerY() - t.cy
                t.vx = 0.5f * t.vx + 0.5f * dx
                t.vy = 0.5f * t.vy + 0.5f * dy
                t.cx += 0.7f * dx
                t.cy += 0.7f * dy
                t.w = b.width()
                t.h = b.height()
                t.missed = 0
                t.hits++
            } else {
                t.missed++
                t.cx += t.vx
                t.cy += t.vy
            }
        }

        for (i in dets.indices) {
            if (!used[i]) {
                val b = dets[i].box
                tracks.add(Track(nextId++, b.centerX(), b.centerY(), b.width(), b.height()))
            }
        }

        tracks.removeAll { it.missed > 6 }
        return tracks.filter { it.hits >= 2 && it.missed <= 3 }
    }
}
