package ru.oxide.aiassist

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.animation.ValueAnimator
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val REQ_CAPTURE = 100
        private const val REQ_NOTIFY = 101
    }

    private lateinit var statusText: TextView
    private lateinit var toggleButton: Button
    private lateinit var pulseDot: View
    private lateinit var aboutText: TextView
    private lateinit var summaryText: TextView
    private lateinit var contentRoot: View
    private lateinit var particles: ParticlesView
    private lateinit var ticker: ThemeTicker
    private var pulse: ObjectAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        toggleButton = findViewById(R.id.toggleButton)
        pulseDot = findViewById(R.id.pulseDot)
        aboutText = findViewById(R.id.aboutText)
        summaryText = findViewById(R.id.summaryText)
        contentRoot = findViewById(android.R.id.content)
        particles = findViewById(R.id.particles)
        ticker = ThemeTicker(contentRoot)

        toggleButton.setOnClickListener { onToggle() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
        findViewById<Button>(R.id.aboutButton).setOnClickListener {
            aboutText.visibility = if (aboutText.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }

    override fun onResume() {
        super.onResume()
        updateUi()
        updateSummary()
        particles.setMode(getSharedPreferences("settings", Context.MODE_PRIVATE).getInt("bg", 1))
        ticker.start()
    }

    private fun updateSummary() {
        val p = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val fps = p.getInt("fps", 5)
        val sens = when (p.getInt("sens", 2)) {
            1 -> "низкая"
            3 -> "высокая"
            else -> "средняя"
        }
        val circle = when (p.getInt("circle", 2)) {
            0 -> "выключен"
            1 -> "малый"
            3 -> "большой"
            else -> "средний"
        }
        val haptic = if (p.getInt("haptic", 1) == 1) "включена" else "выключена"
        val wp = if (p.getBoolean("wp_set", false)) "задана" else "не задана"
        summaryText.text = "Сейчас выбрано\n" +
            "Частота: $fps раз в секунду\n" +
            "Чувствительность: $sens\n" +
            "Круг: $circle\n" +
            "Вибрация: $haptic\n" +
            "Точка на карте: $wp"
    }

    override fun onPause() {
        super.onPause()
        ticker.stop()
        pulse?.cancel()
        pulse = null
    }

    private fun onToggle() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
            toggleButton.postDelayed({ updateUi() }, 300)
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Включите «Поверх других окон» для приложения, затем вернитесь назад",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFY)
            return
        }

        askForScreenCapture()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIFY) {
            askForScreenCapture()
        }
    }

    private fun askForScreenCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return

        if (resultCode == Activity.RESULT_OK && data != null) {
            val intent = Intent(this, OverlayService::class.java)
                .putExtra(OverlayService.EXTRA_CODE, resultCode)
                .putExtra(OverlayService.EXTRA_DATA, data)
            startForegroundService(intent)
            toggleButton.postDelayed({ updateUi() }, 500)
        } else {
            Toast.makeText(
                this,
                "Без разрешения на запись экрана помощник не работает",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun updateUi() {
        pulse?.cancel()
        pulse = null
        pulseDot.scaleX = 1f
        pulseDot.scaleY = 1f
        pulseDot.alpha = 1f

        if (OverlayService.running) {
            toggleButton.text = "Выключить помощника"
            toggleButton.tag = "b_line"
            statusText.text = "Помощник включён"
            pulseDot.tag = "dot_on"

            val anim = ObjectAnimator.ofPropertyValuesHolder(
                pulseDot,
                PropertyValuesHolder.ofFloat("scaleX", 1f, 1.7f),
                PropertyValuesHolder.ofFloat("scaleY", 1f, 1.7f),
                PropertyValuesHolder.ofFloat("alpha", 1f, 0.35f)
            )
            anim.duration = 900
            anim.repeatCount = ValueAnimator.INFINITE
            anim.repeatMode = ValueAnimator.REVERSE
            anim.start()
            pulse = anim
        } else {
            toggleButton.text = "Включить помощника"
            toggleButton.tag = "b_fill"
            statusText.text = "Выключено"
            pulseDot.tag = "dot_off"
        }
        Theme.apply(contentRoot)
    }
}
