package ru.oxide.aiassist

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val REQ_CAPTURE = 100
        private const val REQ_NOTIFY = 101
    }

    private lateinit var statusText: TextView
    private lateinit var toggleButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        toggleButton = findViewById(R.id.toggleButton)

        toggleButton.setOnClickListener { onToggle() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateUi()
    }

    private fun onToggle() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
            toggleButton.postDelayed({ updateUi() }, 300)
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Включите «Поверх других окон» для приложения, затем вернитесь назад",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFY)
            return
        }

        askForScreenCapture()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIFY) {
            askForScreenCapture()
        }
    }

    private fun askForScreenCapture() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_CAPTURE) return

        if (resultCode == Activity.RESULT_OK && data != null) {
            val intent = Intent(this, OverlayService::class.java)
                .putExtra(OverlayService.EXTRA_CODE, resultCode)
                .putExtra(OverlayService.EXTRA_DATA, data)
            startForegroundService(intent)
            toggleButton.postDelayed({ updateUi() }, 500)
        } else {
            Toast.makeText(
                this,
                "Без разрешения на запись экрана помощник не работает",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun updateUi() {
        if (OverlayService.running) {
            toggleButton.text = "ВЫКЛЮЧИТЬ ПОМОЩНИКА"
            toggleButton.setBackgroundResource(R.drawable.btn_dark)
            statusText.text = "● Помощник включён"
        } else {
            toggleButton.text = "ВКЛЮЧИТЬ ПОМОЩНИКА"
            toggleButton.setBackgroundResource(R.drawable.btn_red)
            statusText.text = "○ Выключено"
        }
    }
}
