package ru.oxide.aiassist

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statusText: TextView
    private lateinit var toggleButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        toggleButton = findViewById(R.id.toggleButton)

        toggleButton.setOnClickListener { onToggle() }
        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        updateUi()
    }

    private fun onToggle() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
            toggleButton.postDelayed({ updateUi() }, 300)
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Включите «Поверх других окон» для приложения, затем вернитесь назад",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        startForegroundService(Intent(this, OverlayService::class.java))
        toggleButton.postDelayed({ updateUi() }, 400)
    }

    private fun updateUi() {
        if (OverlayService.running) {
            toggleButton.text = "ВЫКЛЮЧИТЬ ПОМОЩНИКА"
            toggleButton.setBackgroundResource(R.drawable.btn_dark)
            statusText.text = "● Плавающее окно включено"
        } else {
            toggleButton.text = "ВКЛЮЧИТЬ ПОМОЩНИКА"
            toggleButton.setBackgroundResource(R.drawable.btn_red)
            statusText.text = "○ Выключено"
        }
    }
}
