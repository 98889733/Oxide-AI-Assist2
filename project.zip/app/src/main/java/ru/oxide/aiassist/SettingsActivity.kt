package ru.oxide.aiassist

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup

class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val fpsGroup = findViewById<RadioGroup>(R.id.fpsGroup)
        val sensGroup = findViewById<RadioGroup>(R.id.sensGroup)

        when (prefs.getInt("fps", 5)) {
            2 -> findViewById<RadioButton>(R.id.fps2).isChecked = true
            10 -> findViewById<RadioButton>(R.id.fps10).isChecked = true
            else -> findViewById<RadioButton>(R.id.fps5).isChecked = true
        }
        when (prefs.getInt("sens", 2)) {
            1 -> findViewById<RadioButton>(R.id.sens1).isChecked = true
            3 -> findViewById<RadioButton>(R.id.sens3).isChecked = true
            else -> findViewById<RadioButton>(R.id.sens2).isChecked = true
        }

        fpsGroup.setOnCheckedChangeListener { _, id ->
            val fps = when (id) {
                R.id.fps2 -> 2
                R.id.fps10 -> 10
                else -> 5
            }
            prefs.edit().putInt("fps", fps).apply()
        }
        sensGroup.setOnCheckedChangeListener { _, id ->
            val sens = when (id) {
                R.id.sens1 -> 1
                R.id.sens3 -> 3
                else -> 2
            }
            prefs.edit().putInt("sens", sens).apply()
        }

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
    }
}
