package ru.oxide.aiassist

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup

class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val group = findViewById<RadioGroup>(R.id.fpsGroup)

        when (prefs.getInt("fps", 5)) {
            2 -> findViewById<RadioButton>(R.id.fps2).isChecked = true
            10 -> findViewById<RadioButton>(R.id.fps10).isChecked = true
            else -> findViewById<RadioButton>(R.id.fps5).isChecked = true
        }

        group.setOnCheckedChangeListener { _, id ->
            val fps = when (id) {
                R.id.fps2 -> 2
                R.id.fps10 -> 10
                else -> 5
            }
            prefs.edit().putInt("fps", fps).apply()
        }

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
    }
}
