package ru.oxide.aiassist

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var contentRoot: View
    private lateinit var ticker: ThemeTicker
    private val chips = ArrayList<Button>()
    private val resetStatus = Runnable { status.text = "Изменения сохраняются сразу" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        status = findViewById(R.id.saveStatus)
        contentRoot = findViewById(android.R.id.content)
        ticker = ThemeTicker(contentRoot)

        buildThemeChips()
        addSegments(findViewById(R.id.fpsRow), listOf("2 / сек", "5 / сек", "10 / сек"), listOf(2, 5, 10), "fps", 5)
        addSegments(findViewById(R.id.sensRow), listOf("Низкая", "Средняя", "Высокая"), listOf(1, 2, 3), "sens", 2)
        addSegments(findViewById(R.id.circleRow), listOf("Выкл", "Малый", "Средний", "Большой"), listOf(0, 1, 2, 3), "circle", 2)
        addSegments(findViewById(R.id.hapticRow), listOf("Включена", "Выключена"), listOf(1, 0), "haptic", 1)

        // проверка вибрации прямо в настройках
        val vib = getSystemService(Vibrator::class.java)
        val tests = findViewById<LinearLayout>(R.id.testRow)
        addTestButton(tests, "Слева") {
            vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 70), -1))
        }
        addTestButton(tests, "Справа") {
            vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 70, 90, 70), -1))
        }
        addTestButton(tests, "В круге") {
            vib?.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
        }

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
        Theme.apply(contentRoot)
    }

    override fun onResume() {
        super.onResume()
        ticker.start()
    }

    override fun onPause() {
        super.onPause()
        ticker.stop()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun saved() {
        status.text = "Сохранено ✓"
        status.removeCallbacks(resetStatus)
        status.postDelayed(resetStatus, 1500)
    }

    private fun makeButton(label: String): Button {
        val b = Button(this)
        b.text = label
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.minWidth = 0
        b.minHeight = 0
        b.minimumWidth = 0
        b.minimumHeight = 0
        b.setPadding(0, 0, 0, 0)
        return b
    }

    private fun rowParams(): LinearLayout.LayoutParams {
        val d = resources.displayMetrics.density
        val lp = LinearLayout.LayoutParams(0, (64 * d).toInt(), 1f)
        lp.setMargins((3 * d).toInt(), 0, (3 * d).toInt(), 0)
        return lp
    }

    // выбор цвета приложения: 9 кружков по 3 в ряд
    private fun buildThemeChips() {
        val grid = findViewById<LinearLayout>(R.id.themeGrid)
        grid.removeAllViews()
        chips.clear()
        val d = resources.displayMetrics.density
        var row = LinearLayout(this)
        for (i in Theme.names.indices) {
            if (i % 3 == 0) {
                row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                val lp = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                lp.topMargin = (6 * d).toInt()
                grid.addView(row, lp)
            }
            val b = makeButton(Theme.names[i])
            b.textSize = 13f
            b.setOnClickListener {
                prefs.edit().putInt("theme", i).apply()
                refreshChips()
                Theme.apply(contentRoot)
                saved()
            }
            row.addView(b, rowParams())
            chips.add(b)
        }
        refreshChips()
    }

    private fun refreshChips() {
        val d = resources.displayMetrics.density
        val cur = prefs.getInt("theme", 0)
        for (i in chips.indices) {
            chips[i].background = Theme.chip(i, i == cur, d)
            chips[i].setTextColor(Theme.chipTextColor(i))
        }
    }

    private fun addSegments(
        row: LinearLayout,
        labels: List<String>,
        values: List<Int>,
        key: String,
        default: Int
    ) {
        val buttons = ArrayList<Button>()
        fun refresh() {
            val cur = prefs.getInt(key, default)
            for (i in buttons.indices) {
                buttons[i].tag = if (values[i] == cur) "b_fill" else "b_line"
            }
            Theme.apply(contentRoot)
        }
        for (i in labels.indices) {
            val b = makeButton(labels[i])
            b.setOnClickListener {
                prefs.edit().putInt(key, values[i]).apply()
                refresh()
                saved()
            }
            row.addView(b, rowParams())
            buttons.add(b)
        }
        refresh()
    }

    private fun addTestButton(row: LinearLayout, label: String, action: () -> Unit) {
        val b = makeButton(label)
        b.tag = "b_line"
        b.setOnClickListener { action() }
        row.addView(b, rowParams())
    }
}
