package ru.oxide.aiassist

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup

class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        val fpsGroup = findViewById<RadioGroup>(R.id.fpsGroup)
        val sensGroup = findViewById<RadioGroup>(R.id.sensGroup)
        val circGroup = findViewById<RadioGroup>(R.id.circGroup)
        val hapGroup = findViewById<RadioGroup>(R.id.hapGroup)

        when (prefs.getInt("fps", 5)) {
            2 -> findViewById<RadioButton>(R.id.fps2).isChecked = true
            10 -> findViewById<RadioButton>(R.id.fps10).isChecked = true
            else -> findViewById<RadioButton>(R.id.fps5).isChecked = true
        }
        when (prefs.getInt("sens", 2)) {
            1 -> findViewById<RadioButton>(R.id.sens1).isChecked = true
            3 -> findViewById<RadioButton>(R.id.sens3).isChecked = true
            else -> findViewById<RadioButton>(R.id.sens2).isChecked = true
        }

        when (prefs.getInt("circle", 2)) {
            0 -> findViewById<RadioButton>(R.id.circ0).isChecked = true
            1 -> findViewById<RadioButton>(R.id.circ1).isChecked = true
            3 -> findViewById<RadioButton>(R.id.circ3).isChecked = true
            else -> findViewById<RadioButton>(R.id.circ2).isChecked = true
        }

        circGroup.setOnCheckedChangeListener { _, id ->
            val c = when (id) {
                R.id.circ0 -> 0
                R.id.circ1 -> 1
                R.id.circ3 -> 3
                else -> 2
            }
            prefs.edit().putInt("circle", c).apply()
        }

        if (prefs.getInt("haptic", 1) == 1) {
            findViewById<RadioButton>(R.id.hap1).isChecked = true
        } else {
            findViewById<RadioButton>(R.id.hap0).isChecked = true
        }
        hapGroup.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("haptic", if (id == R.id.hap0) 0 else 1).apply()
        }

        fpsGroup.setOnCheckedChangeListener { _, id ->
            val fps = when (id) {
                R.id.fps2 -> 2
                R.id.fps10 -> 10
                else -> 5
            }
            prefs.edit().putInt("fps", fps).apply()
        }
        sensGroup.setOnCheckedChangeListener { _, id ->
            val sens = when (id) {
                R.id.sens1 -> 1
                R.id.sens3 -> 3
                else -> 2
            }
            prefs.edit().putInt("sens", sens).apply()
        }

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
    }
}
