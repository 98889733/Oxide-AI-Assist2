package ru.oxide.aiassist

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private val resetStatus = Runnable { status.text = "Изменения сохраняются сразу" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)
        status = findViewById(R.id.saveStatus)

        addSegments(findViewById(R.id.fpsRow), listOf("2 / сек", "5 / сек", "10 / сек"), listOf(2, 5, 10), "fps", 5)
        addSegments(findViewById(R.id.sensRow), listOf("Низкая", "Средняя", "Высокая"), listOf(1, 2, 3), "sens", 2)
        addSegments(findViewById(R.id.circleRow), listOf("Выкл", "Малый", "Средний", "Большой"), listOf(0, 1, 2, 3), "circle", 2)
        addSegments(findViewById(R.id.hapticRow), listOf("Включена", "Выключена"), listOf(1, 0), "haptic", 1)

        // проверка вибрации прямо в настройках
        val vib = getSystemService(Vibrator::class.java)
        val tests = findViewById<LinearLayout>(R.id.testRow)
        addTestButton(tests, "Слева") {
            vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 70), -1))
        }
        addTestButton(tests, "Справа") {
            vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 70, 90, 70), -1))
        }
        addTestButton(tests, "В круге") {
            vib?.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
        }

        findViewById<Button>(R.id.backButton).setOnClickListener { finish() }
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun makeButton(label: String): Button {
        val b = Button(this)
        b.text = label
        b.setTextColor(Color.WHITE)
        b.textSize = 15f
        b.minWidth = 0
        b.minHeight = 0
        b.minimumWidth = 0
        b.minimumHeight = 0
        b.setPadding(0, 0, 0, 0)
        return b
    }

    private fun rowParams(): LinearLayout.LayoutParams {
        val d = resources.displayMetrics.density
        val lp = LinearLayout.LayoutParams(0, (64 * d).toInt(), 1f)
        lp.setMargins((3 * d).toInt(), 0, (3 * d).toInt(), 0)
        return lp
    }

    private fun addSegments(
        row: LinearLayout,
        labels: List<String>,
        values: List<Int>,
        key: String,
        default: Int
    ) {
        val buttons = ArrayList<Button>()
        fun refresh() {
            val cur = prefs.getInt(key, default)
            for (i in buttons.indices) {
                buttons[i].setBackgroundResource(
                    if (values[i] == cur) R.drawable.btn_red else R.drawable.btn_dark
                )
            }
        }
        for (i in labels.indices) {
            val b = makeButton(labels[i])
            b.setOnClickListener {
                prefs.edit().putInt(key, values[i]).apply()
                refresh()
                status.text = "Сохранено ✓"
                status.removeCallbacks(resetStatus)
                status.postDelayed(resetStatus, 1500)
            }
            row.addView(b, rowParams())
            buttons.add(b)
        }
        refresh()
    }

    private fun addTestButton(row: LinearLayout, label: String, action: () -> Unit) {
        val b = makeButton(label)
        b.setBackgroundResource(R.drawable.btn_dark)
        b.setOnClickListener { action() }
        row.addView(b, rowParams())
    }
}
