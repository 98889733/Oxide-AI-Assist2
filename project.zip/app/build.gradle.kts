import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.oxide.aiassist"
    compileSdk = 34

    defaultConfig {
        applicationId = "ru.oxide.aiassist"
        minSdk = 26
        targetSdk = 33
        versionCode = 9
        versionName = "0.9"
        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    signingConfigs {
        create("fixed") {
            storeFile = file("gravity.keystore")
            storeType = "pkcs12"
            storePassword = "gravitybot"
            keyAlias = "gravity"
            keyPassword = "gravitybot"
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    androidResources {
        noCompress += "tflite"
    }
}

dependencies {
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
    implementation("com.google.mlkit:text-recognition:16.0.0")
    implementation("com.google.android.gms:play-services-tasks:18.1.0")
}

// Скачиваем готовую модель распознавания (EfficientDet-Lite0, Google) при сборке
val modelFile = file("src/main/assets/detector.tflite")
val downloadModel by tasks.registering {
    outputs.file(modelFile)
    doLast {
        if (modelFile.exists() && modelFile.length() > 100_000) return@doLast
        modelFile.parentFile.mkdirs()
        val urls = listOf(
            "https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/float32/1/efficientdet_lite0.tflite",
            "https://storage.googleapis.com/mediapipe-models/object_detector/efficientdet_lite0/int8/1/efficientdet_lite0.tflite"
        )
        var ok = false
        for (u in urls) {
            try {
                URL(u).openStream().use { input ->
                    modelFile.outputStream().use { out -> input.copyTo(out) }
                }
                if (modelFile.length() > 100_000) {
                    ok = true
                    break
                }
            } catch (e: Exception) {
                println("Не удалось скачать $u: ${e.message}")
            }
        }
        if (!ok) throw GradleException("Не удалось скачать модель распознавания")
    }
}
tasks.configureEach {
    if (name == "preBuild") dependsOn(downloadModel)
}
